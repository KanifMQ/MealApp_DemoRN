import React from 'react'
import { View, Text, StyleSheet } from 'react-native'
import { MEALS } from '../data/dummy-data'
import MealList from '../Components/MealList'
import { HeaderButtons, Item } from 'react-navigation-header-buttons'
import CustomHeaderButton from '../Components/CustomHeaderButton'

const FavouritesScreen = props => {

    const favList=MEALS.filter(meal=>meal.id==='m1' || meal.id==='m2')
    return (
        <MealList itemData={favList} navigation={props.navigation}></MealList>
    )
 
}

FavouritesScreen.navigationOptions = (navData) => {
    return {
        headerTitle: "My Favourites",
        headerLeft: () => {
            return (
                <HeaderButtons HeaderButtonComponent={CustomHeaderButton}>
                    <Item
                        title="Menu" iconName="ios-menu" onPress={() => {
                            navData.navigation.toggleDrawer()
                        }}>
                    </Item>
                </HeaderButtons >


            )
        }
    }
}
styles = StyleSheet.create({
    screen: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center"
    }
})

export default FavouritesScreen