import React from 'react'
import {View,Text,StyleSheet} from 'react-native'
import { HeaderButtons, Item } from 'react-navigation-header-buttons'
import CustomHeaderButton from '../Components/CustomHeaderButton'

const FilterScreen=props=>{
    return(
        <View>
            <Text>This is FilterScreen</Text>
        </View>
    )

}
styles=StyleSheet.create({
    screen:{
        flex:1,
        alignItems:"center",
        justifyContent:"center"
    }
})



FilterScreen.navigationOptions = (navData) => {
    return {
        headerTitle: "Filter Meals",
        headerLeft: () => {
            return (
                <HeaderButtons HeaderButtonComponent={CustomHeaderButton}>
                    <Item
                        title="Menu" iconName="ios-menu" onPress={() => {
                            navData.navigation.toggleDrawer()
                        }}>
                    </Item>
                </HeaderButtons >


            )
        }
    }
}
export default FilterScreen