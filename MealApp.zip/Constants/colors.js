export default{
    primaryColor:'#4a148c',
    accentColor:'#ff6f00'
}