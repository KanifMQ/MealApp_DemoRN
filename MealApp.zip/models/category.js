class Category{
    constructor(id,catName,catColor){
        this.id=id
        this.catName=catName
        this.catColor=catColor
    }
}

export default Category;